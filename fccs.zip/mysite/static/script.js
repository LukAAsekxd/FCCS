// script.js

document.addEventListener('DOMContentLoaded', () => {
    // Shrink header on scroll
    window.addEventListener('scroll', handleScroll);

    // Slide footer on scroll
    window.addEventListener('scroll', handleFooterSlide);
});

function handleScroll() {
    const header = document.querySelector('.header');
    const logo = document.querySelector('.logo img');

    if (window.scrollY > 50) {
        header.classList.add('shrink');
        logo.classList.add('shrink-logo');
    } else {
        header.classList.remove('shrink');
        logo.classList.remove('shrink-logo');
    }
}

function handleFooterSlide() {
    const footer = document.querySelector('footer');

    // Calculate scroll threshold based on document height
    const scrollThreshold = document.documentElement.scrollHeight - window.innerHeight - 100;

    if (window.scrollY > scrollThreshold) {
        footer.classList.add('slide-up');
    } else {
        footer.classList.remove('slide-up');
    }
}

function sortProducts() {
    const select = document.getElementById('sort');
    const selectedOption = select.value;
    let products = Array.from(document.querySelectorAll('.product'));

    switch (selectedOption) {
        case 'asc':
            products.sort((a, b) => parseFloat(a.dataset.price) - parseFloat(b.dataset.price));
            break;
        case 'desc':
            products.sort((a, b) => parseFloat(b.dataset.price) - parseFloat(a.dataset.price));
            break;
        case 'default':
        default:
            // No sorting, keep default order as is (by DOM order)
            break;
    }

    const productGrid = document.getElementById('product-grid');
    // Clear existing products from grid
    while (productGrid.firstChild) {
        productGrid.removeChild(productGrid.firstChild);
    }

    // Append sorted products back to grid
    products.forEach(product => {
        productGrid.appendChild(product);
    });
}
