from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('tym.html')

@app.route('/tym')
def tym():
    return render_template('tym.html')

@app.route('/hraci')
def hraci():
    return render_template('hraci.html')

@app.route('/udalosti')
def udalosti():
    return render_template('udalosti.html')

@app.route('/e-shop')
def eshop():
    return render_template('e-shop.html')

@app.route('/info')
def info():
    return render_template('info.html')

@app.route('/hrac/<name>')
def hrac(name):
    return render_template(f'hraci/{name}.html')

@app.route('/produkty/<product>')
def produkty(product):
    return render_template(f'produkty/{product}.html')

if __name__ == '__main__':
    app.run(debug=True)
